import logo from './logo.svg';
import './App.css';
import CounterContainer from "./components/CounterContainer"
import ToDoContainer from "./components/ToDoContainer";


function App() {
  return (
    <div className="App">
      <ToDoContainer/>
    </div>
  );
}

export default App;
